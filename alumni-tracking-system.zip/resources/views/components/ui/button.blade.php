@props([
  'variant' => 'default',
  'size' => 'default',
])

@php
$base = "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover-elevate active-elevate-2";

$variants = [
  'default' => "bg-primary text-primary-foreground border border-primary-border",
  'destructive' => "bg-destructive text-destructive-foreground border border-destructive-border",
  'outline' => "border [border-color:var(--button-outline)] shadow-xs active:shadow-none",
  'secondary' => "border bg-secondary text-secondary-foreground border border-secondary-border",
  'ghost' => "border border-transparent",
];

$sizes = [
  'default' => "min-h-9 px-4 py-2",
  'sm' => "min-h-8 rounded-md px-3 text-xs",
  'lg' => "min-h-10 rounded-md px-8",
  'icon' => "h-9 w-9",
];

$cls = trim($base.' '.($variants[$variant] ?? $variants['default']).' '.($sizes[$size] ?? $sizes['default']));
@endphp

<button {{ $attributes->merge(['class' => $cls]) }}>
  {{ $slot }}
</button>
